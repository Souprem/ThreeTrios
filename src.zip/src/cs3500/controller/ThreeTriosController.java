package cs3500.Controller;

public class ThreeTriosController {
}
