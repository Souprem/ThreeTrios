package cs3500.model;

/**
 * An enum representing a status for a ThreeTrios board.
 */
public enum Status {
  EMPTY, HOLE, FULL
}
