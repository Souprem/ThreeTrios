import org.junit.Before;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import cs3500.ThreeTrios;
import cs3500.model.MaxFlipTriosMockModel;
import cs3500.model.ThreeTriosCard;
import cs3500.model.ThreeTriosModel;
import cs3500.model.TriosModel;

public class TestMockAIStrategies {

  TriosModel<ThreeTriosCard> model;

  @Before
  public void init() {
//    model = new MaxFlipTriosMockModel();
  }

  @Test
  public void testMaxFlipEasyNoChoice() throws IOException {

  }

}
